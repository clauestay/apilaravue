<template>
    <div>
    
    <section class="jumbotron text-center">
        <div class="container">
          <h1 class="jumbotron-heading">Error 404 </h1>
          </div>
      </section>

      <div class="container">
          <div class="row justify-content-center">
              <div class="col-md-8">
                  <p>Página no encontrada...</p>
              </div>
          </div>
      </div>
        
    </div>
</template>